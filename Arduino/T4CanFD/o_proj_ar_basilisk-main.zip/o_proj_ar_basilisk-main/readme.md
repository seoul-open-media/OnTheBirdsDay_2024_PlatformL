## Todo
- Auto-moonwalk
- GhostWalk -> Use global variable
- XbeeReplySender