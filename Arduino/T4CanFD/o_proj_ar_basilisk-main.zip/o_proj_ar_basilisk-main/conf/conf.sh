moteus_tool -t 1,2 --write-config conf.cfg
