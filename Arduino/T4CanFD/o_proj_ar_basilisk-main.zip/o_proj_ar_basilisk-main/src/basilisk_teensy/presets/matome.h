#pragma once

#include "mags.h"
#include "pivots.h"
