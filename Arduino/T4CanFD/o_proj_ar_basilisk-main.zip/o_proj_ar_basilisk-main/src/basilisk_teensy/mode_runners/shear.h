#pragma once

#include "meta.h"

void ModeRunners::Shear(Basilisk* b) {
  auto& m = b->cmd_.mode;

  switch (m) {
    case M::Shear_Init: {
    } break;
    case M::Shear_Move: {
    } break;
    default:
      break;
  }
}
