#pragma once

#include "meta.h"

void ModeRunners::Gee(Basilisk* b) {}
