from commander import BasiliskCommander


def main():
    cmdr = BasiliskCommander()
    cmdr.mainloop()


if __name__ == "__main__":
    main()
