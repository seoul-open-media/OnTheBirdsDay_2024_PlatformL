#!/usr/bin/bash

make install pdincludepath=~/repos/_clones/pure-data/pure-data/src/ objectsdir=~/Documents/Pd/externals
